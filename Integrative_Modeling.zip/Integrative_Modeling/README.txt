Dear reader,

Please find in this folder documentation regarding integrative modeling described in the publication Structural visualization of de novo transcription initiation by Saccharomyces cerevisiae RNA polymerase II.

The folder should contain the following entries:
1. Modeling_Script - A folder containing the modeling.py script, used in modeling using the Integrative Modeling Platform (IMP) version 2.13.0.
2. Statistics - a folder containing the standard output textfiles returned from analysis of the resulting model ensemble from modeling. these results, obtained through IMP's imp_sampcon command encompass a total of eight files beginning with the prefix "xls_alone", relating to the input data used for this modeling.
3. Final_Model - a folder containing the resulting model obtained from analysis of the ensemble under the subfolder cluster.0 and a script designed for visializing the model in UCSF Chimera X.
4. README.txt - this text file deatiling the contents of the folder.

For any inquiries regarding the integrative modeling procedure applied here, please direct all questions to:
gorbea@pennmedicine.upenn.edu.

Best regards,

Jose Gorbea & The Murakami Lab Team
